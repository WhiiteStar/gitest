#include <iostream>
#include "include/Client.h"
#include "include/Medicament.h"
#include "include/Pharmacie.h"
#include <string>
#include <list>

using namespace std;

int main()
{
    Medicament medicament1("Fenergand", "Lor�al",TauxRemboursement::taux100pr,20);
    Medicament medicament2("Euphon", "Boiron",TauxRemboursement::taux100pr,8);
    Medicament medicament3("Daphalgan", "Lor�al",TauxRemboursement::taux65pr,5);
    Medicament medicament4("N�ocodion", "Boiron",TauxRemboursement::aucun,4);


    Client client1("Benoit","MMA");
    Client client2("Francis","AXA");

    Pharmacie pharmacie1("Pharmacie Croix Bleu");


    pharmacie1.AjouterMedicament(&medicament1);
    pharmacie1.AjouterMedicament(&medicament2);
    pharmacie1.AjouterMedicament(&medicament3);
    pharmacie1.AjouterMedicament(&medicament4);

    pharmacie1.Approvisionnement(medicament1,38);
    pharmacie1.Approvisionnement(medicament2,35);

    pharmacie1.Achat(client1,medicament1,1);
    pharmacie1.Achat(client1,medicament2,2);

    pharmacie1.Information();

    system("pause");
    return 0;
}
