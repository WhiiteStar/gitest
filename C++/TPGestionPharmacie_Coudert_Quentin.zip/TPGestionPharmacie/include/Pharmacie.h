#ifndef PHARMACIE_H
#define PHARMACIE_H

#include <iostream>
#include <string>
#include <list>
using namespace std;

class Pharmacie
{
    public:
        Pharmacie();
        Pharmacie(std::string nom);
        virtual ~Pharmacie();
        void AjouterClient(Client* client);
        void AjouterMedicament(Medicament* medicament);
        void Approvisionnement(Medicament& medicament,int qte);
        void Achat(Client& client,Medicament& medicament,int qte);
        void Information ();

    protected:

    private:
        std::string _nom;
        list<Client*> _clients;
        list<Medicament*> _medicaments;



};

#endif // PHARMACIE_H
