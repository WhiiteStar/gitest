#ifndef MEDICAMENT_H
#define MEDICAMENT_H

#include <iostream>
#include <string>
#include <list>
using namespace std;


class Medicament
{
    public:
        Medicament();
        virtual ~Medicament();
        Medicament(std::string Nom,std::string Fabriquant,TauxRemboursement Remboursement,double prix);
       double GetPrix();
       int GetStock();
       int GetRemboursement();
       void Acheter(int qte);
       void Vendre (int qte);
       void Information ();
    protected:

    private:
        std::string _nom;
        std::string _fabriquant;
        double _prix;
        TauxRemboursement _remboursement;
        int _stock;
};

#endif // MEDICAMENT_H
