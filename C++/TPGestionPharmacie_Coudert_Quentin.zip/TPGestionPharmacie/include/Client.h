#ifndef CLIENT_H
#define CLIENT_H

#include <iostream>
#include <string>
#include <list>
using namespace std;

enum class TauxRemboursement : int {
    taux100pr = 100,taux65pr = 65,taux30pr =30,taux15pr = 15,aucun =0};

class Client
{
    public:
        Client();
        Client(std::string nom, std::string mutuel);
        virtual ~Client();
        void Augmenter(int montant);
        void Information();

    protected:

    private:
        std::string _nom;
        std::string _mutuel;
        double _credit;

};

#endif // CLIENT_H
