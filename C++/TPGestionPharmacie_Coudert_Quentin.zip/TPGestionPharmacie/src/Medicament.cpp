#include "../include/Client.h"
#include "../include/Medicament.h"
#include "../include/Pharmacie.h"
#include <iostream>
#include <string>
#include <list>
using namespace std;

Medicament::Medicament()
{
    //ctor
}

Medicament::Medicament(std::string Nom,std::string Fabriquant,TauxRemboursement Remboursement,double Prix)
{
    _nom = Nom;
    _fabriquant = Fabriquant;
    _rembousement = Remboursement;
    _prix = Prix;
    _stock = 0;
}
void Medicament::Vendre(int qte)
{
	if (_stock >= qte) {
		_stock -= qte;
	}
	else {
		cout << "Stock insufisant pour " << _nom << endl;
	}

}

void Medicament::Acheter(int qte)
{
    _stock += qte;

}
void Medicament::Information()
{
   cout << "Nom : " << _nom << endl;
	cout << "Fabriquant : " << _fabriquant << endl;
	cout << "Prix : " << _prix << endl;
	cout << "Taux de Remboursment : "<< _remboursement << endl;
	cout << "Stock : " << _stock << endl;
}
double Medicament::GetPrix()
{
    return _prix;
}

double Medicament::GetStock()
{
    return _stock;
}
Medicament::~Medicament()
{
    //dtor
}
