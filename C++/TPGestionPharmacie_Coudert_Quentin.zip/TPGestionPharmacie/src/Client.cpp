#include "../include/Client.h"
#include "../include/Medicament.h"
#include "../include/Pharmacie.h"
#include <iostream>
#include <string>
#include <list>

using namespace std;
Client::Client()
{
    //ctor
}
Client::Client(std::string nom, std::string mutuel)
{
    _nom = nom;
    _mutuel = mutuel;
    _credit =0;
}

Client::~Client()
{
    //dtor
}

void Client::Augmenter(int montant)
{
 _credit += montant;
}

void Client::Information()
{
   cout << "Nom : " << _nom << endl;
	cout << "Mutuel : " << _mutuel << endl;
	cout << "Cr�dit : " << _credit << endl;
}
