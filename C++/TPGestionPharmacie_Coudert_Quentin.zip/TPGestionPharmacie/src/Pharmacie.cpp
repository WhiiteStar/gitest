#include "../include/Pharmacie.h"
#include "../include/Client.h"
#include "../include/Medicament.h"
#include <iostream>
#include <string>
#include <list>

using namespace std;

Pharmacie::Pharmacie()
{
    //ctor
}

Pharmacie::Pharmacie(std::string nom);
{
    _nom = nom;
}

Pharmacie::~Pharmacie()
{
    //dtor
}

void Pharmacie::Information()
{
    cout << "Nom de la Pharmacie: " << _nom << endl;
	cout << "Liste des Clients : " << _clients << endl;
	cout<<Client.Information()<<endl;
	cout << "Liste des M�dicaments : " << _prix << endl;
	cout<<Medicament.Information()<<endl;

}

void Pharmacie::Achat(Client& client,Medicament& medicament,int qte)
{
    	if (_stock >= qte) {
		_stock -= qte;
	}
	else {
		cout << "Stock insufisant pour " << medicament << endl;
	}
}

void Pharmacie::AjouterClient(Client* client)
{
    _clients.push_back(client);
}

void Pharmacie::AjouterMedicament(Medicament* medicament)
{
    _medicaments.push_back(medicament);
}

void Pharmacie::Approvisionnement(Medicament& medicament,int qte)
{

}

